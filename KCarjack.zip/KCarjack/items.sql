INSERT INTO `items` (name, label, `limit`) VALUES
('lockpick', 'Crochet', 50)
;