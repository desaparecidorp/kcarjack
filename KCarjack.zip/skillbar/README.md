![image](https://user-images.githubusercontent.com/31771817/135759503-53720566-aa19-4435-a4ce-47975168dc7a.png)# skill-bar

fivem skillbar  - Ron#7000 scammer, please becarfuel he will steal your script and sell it

usages : 
usages 'exports["skillbar"]:CreateSkillbar(1, "easy")'

--the one is how much times the skillbar gonna showup
--the easy represants the diffuclty

Join rockstar services for more.  -https://discord.gg/pAv9z57m7b
